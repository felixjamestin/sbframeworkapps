const Constants = {
  // NOTE: Add key for new apps
  appKeys: {
    sb: "SECONDBRAIN",
    rmed: "RAMANA_MAHARISHI_ENGLISH_DAILY",
    aed: "ADVAITA_ENGLIGH_DAILY",
    ted: "TAO_ENGLIGH_DAILY",
    red: "RUMI_ENGLISH_DAILY",
    bed: "BIBLE_ENGLISH_DAILY",
    bsd: "BIBLE_SPANISH_DAILY"
  }
};

module.exports = Constants;
